package stringCalculator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * <h1>String Calculator</h1>
 * <p>A simple String calculator By Vigor</p>
 *
 * @author  Vigor
 * @version Sneaky-1.0,0
 * @see 2019-5-23
 */
public class SneakyStringCalculator {
    /**
     * This method is used to add numbers from string
     * @param numbers The String contain numbers with or without custom delimiters
     * @return int The integer value after addition
     * @exception Exception On add a negative number (ex: -1)
     * */
    public int Add(String numbers){
        if (numbers.isEmpty()) return 0;
        int temp, total = 0;
        Matcher m = Pattern.compile("[+-]?[0-9][0-9]*")
                .matcher(numbers);
        while (m.find()) {
            temp = Integer.parseInt(m.group());
            if (temp < 0) throw new IllegalArgumentException("Negatives not allowed : " + temp);
            if (temp <= 1000) total = total + temp;
        }
        return total;
    }

    /**
     * This is a temp method for quick test.
     * It could be removed.
     * */
    public static void main(String[] args) {
        SneakyStringCalculator a = new SneakyStringCalculator();
        String stringToTest = "1,2,3";
        System.out.println(a.Add(stringToTest));
    }
}