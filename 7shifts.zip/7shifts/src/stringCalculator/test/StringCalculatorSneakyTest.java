package stringCalculator.test;

import org.junit.Test;
import stringCalculator.SneakyStringCalculator;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import static org.junit.Assert.assertEquals;

public class StringCalculatorSneakyTest {
    SneakyStringCalculator sneakyStringCalculator = new SneakyStringCalculator();
    /**
     * A Helper method which help junit to run test from csv file.
     * @param csvFile file name
     * @param csvSplitBy delimiter for csv file
     * */
    private void csvTestRunner(String csvFile, String csvSplitBy) throws Exception {
        String line;
        int result;
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            while ((line = br.readLine()) != null) {
                String[] parsedStringArr = line.split(csvSplitBy);
                result = sneakyStringCalculator.Add(parsedStringArr[0]);
                try{
                    assertEquals(Integer.parseInt(parsedStringArr[1]),result);
                }catch (Exception exception){
                    System.out.println(exception.getMessage() + " Please check your csv syntax");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private final String path = "src" + File.separator + "stringCalculator" + File.separator + "test"+ File.separator;
    @Test
    public void SMOKE_TEST_1() throws Exception {
        int result = sneakyStringCalculator.Add("2");
        assertEquals(2,result);
    }
    @Test
    public void SMOKE_TEST_2() throws Exception {
        int result = sneakyStringCalculator.Add("2\n,3");
        assertEquals(5,result);
    }
    @Test
    public void SMOKE_TEST_3() throws Exception {
        int result = sneakyStringCalculator.Add("//.\n1.2.3");
        assertEquals(6,result);
    }
    @Test
    public void SMOKE_TEST_4() throws Exception {
        int result = sneakyStringCalculator.Add("//$$\n1$$2$$3");
        assertEquals(6,result);
    }
    @Test
    public void POSITIVE_TEST() throws Exception {
        String csvFile = this.path+"test.csv";
        String cvsSplitBy = "\\|\\|\\|";
        csvTestRunner(csvFile, cvsSplitBy);
    }

    @Test
    public void CUSTOM_DELIMITER_TEST_1() throws Exception {
        int result = sneakyStringCalculator.Add("//;\n1;3;4");
        assertEquals(8,result);
    }
    @Test
    public void CUSTOM_DELIMITER_TEST_2() throws Exception {
        int result = sneakyStringCalculator.Add("//$\n1$3$4");
        assertEquals(8,result);
    }
    @Test
    public void CUSTOM_DELIMITER_TEST_3() throws Exception {
        int result = sneakyStringCalculator.Add("//@\n1@3@4");
        assertEquals(8,result);
    }
    @Test
    public void CUSTOM_DELIMITER_TEST_4() throws Exception {
        int result = sneakyStringCalculator.Add("//.\n1.3.4");
        assertEquals(8,result);
    }

    @Test
    public void BONUS_TEST() throws Exception {
        int result = sneakyStringCalculator.Add("//@@\n1@@3@@4");
        assertEquals(8,result);
        result = sneakyStringCalculator.Add("//###\n1###3###4");
        assertEquals(8,result);
        result = sneakyStringCalculator.Add("//>>\n1>>3>>4");
        assertEquals(8,result);
        result = sneakyStringCalculator.Add("//@,#\n1@3#4");
        assertEquals(8,result);

    }
}
