package stringCalculator;

/**
 * <h1>String Calculator</h1>
 * <p>A simple String calculator By Vigor</p>
 *
 * @author  Vigor
 * @version 1.0
 * @see 2019-5-23
 */
public class StringCalculator {
    /**
     * This method is used to add numbers from string
     * @param numbers The String contain numbers with or without custom delimiters
     * @return int The integer value after addition
     * @exception NumberFormatException On Parsing integer from string (ex: 1$)
     * @exception Exception On add a negative number (ex: -1)
     * */
    public int Add(String numbers) throws Exception {
        int temp, total = 0;
        String [] integerArr, tempArr;
        if (numbers.isEmpty()) return 0;
        // Getting numbers from the string
        if (numbers.length()<4||numbers.charAt(0)!=numbers.charAt(1) || numbers.charAt(1) !='/' && !numbers.contains("\n")){
            // The string does not match "//[delimiter]\n[delimiter separated numbers]"
            numbers=this.handleNewLines(numbers);
            integerArr= numbers.split(",");
        }else{
            // The string match "//[delimiter]\n[delimiter separated numbers]"
            numbers = numbers.substring(2);
            tempArr = numbers.split("\\n|\\r|\\r\\n",2);
            String delimiters = tempArr[0];
            numbers = this.handleNewLines(tempArr[1]);
            System.out.println(numbers);
            integerArr= this.delimiter(delimiters, numbers);
        }
        // Add numbers
        for (String s: integerArr){
            try{
                if (s.equals("")) continue;
                temp = Integer.parseInt(s);
            }catch (NumberFormatException exception){
                System.out.println(exception.getMessage() + " is not a valid integer value\nSkipping ...");
                continue; //TODO handle the exception, it depends
            }
            if (temp < 0) throw new Exception("Negatives not allowed : " + temp);
            if (temp <= 1000) total = total + temp; //Numbers larger than 1000 should be ignored.
        }
        return total;
    }

    /**
     * This method is used to clean all the newline in string
     * @param inputString The string which may contains newline
     * @return String This returns the cleaned string
     * */
    public String handleNewLines(String inputString){
        return inputString.replaceAll("\\n|\\r|\\r\\n","");
    }

    /**
     * This method is used to delimit the number string into addable array
     * @param delimiterString The string which contains delimiter(s)
     * @param numberString The string which contains numbers(s)
     * @return String [] This returns the array of the addable value for example [1,2,3]
     * */
    public String[] delimiter(String delimiterString, String numberString){
        String [] delimiterArr =delimiterString.split(",");
        System.out.println(this.buildDelimiterRegex(delimiterArr));
        return numberString.split(this.buildDelimiterRegex(delimiterArr));
    }
    /***
     * This method is used to add escape slash in front of special character to a given string
     * @param inputString This is a string which may contains metacharacters (Not Ready for Regex)
     * @return cleaned regex string This is a string that metacharacters are escaped (Ready for Regex)
     **/
    public String escapeMetaCharacters(String inputString){
        final String[] metaCharacters = {"\\","^","$","{","}","[","]","(",")","*","+","?","|","<",">","-","&","%","."};
        for (String metaCharacter : metaCharacters) {
            if (inputString.contains(metaCharacter)) {
                inputString = inputString.replace(metaCharacter, "\\" + metaCharacter);
            }
        }
        return inputString;
    }
    /***
     * This method is used to Build Regex by given Delimiters Array
     * @param delimiters [] Delimiters array
     * @return cleaned and optimized regex string
     **/
    public String buildDelimiterRegex(String [] delimiters){
        StringBuilder sb = new StringBuilder();
        for (int i =0;i<delimiters.length;i++){
            sb.append(escapeMetaCharacters(delimiters[i]));
            if(i!=delimiters.length-1)sb.append("|");
        }
        return sb.toString();
    }
    /**
     * This is a temp method for quick test.
     * It could be removed.
     * */
    public static void main(String[] args) throws Exception {
        String stringToTest = "2\n,3";
        StringCalculator m = new StringCalculator();
        System.out.println(m.Add(stringToTest));
    }
}